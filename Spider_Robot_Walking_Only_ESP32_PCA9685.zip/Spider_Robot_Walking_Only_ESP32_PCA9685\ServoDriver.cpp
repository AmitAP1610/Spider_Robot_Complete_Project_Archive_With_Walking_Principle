#include "ServoDriver.h"

ServoDriver::ServoDriver()
    : m_pwm(0x40),
      m_i2cAddr(0x40),
      m_connected(false)
{
    for (int i = 0; i < 12; i++) {
        m_currentAngleDeg[i] = g_servoCalibration[i].centerAngleDeg;
        m_targetAngleDeg[i]  = g_servoCalibration[i].centerAngleDeg;
    }
}

bool ServoDriver::init(uint8_t sdaPin, uint8_t sclPin, uint8_t i2cAddr) {
    m_i2cAddr = i2cAddr;
    m_pwm = Adafruit_PWMServoDriver(m_i2cAddr);

    Wire.begin(sdaPin, sclPin);
    Wire.setClock(100000); // 100 kHz standard I2C speed for maximum reliability with long jumper wires

    // Probe PCA9685 on I2C bus
    Wire.beginTransmission(m_i2cAddr);
    uint8_t error = Wire.endTransmission();
    if (error == 0) {
        m_connected = true;
    } else {
        m_connected = false;
        return false;
    }

    m_pwm.begin();
    m_pwm.setPWMFreq(ServoCalibration::PWM_FREQUENCY_HZ);
    delay(20);

    // Initialize all 12 channels to their calibrated center angles
    for (int i = 0; i < 12; i++) {
        m_currentAngleDeg[i] = g_servoCalibration[i].centerAngleDeg;
        m_targetAngleDeg[i]  = g_servoCalibration[i].centerAngleDeg;
        writeServoHardware(i, m_currentAngleDeg[i]);
    }

    return true;
}

void ServoDriver::update(float dt, const LegJointAngles targetAngles[4]) {
    if (!m_connected) return;

    // Slew-rate maximum angle change for this timestep
    float maxDeltaDeg = GaitConfig::MAX_JOINT_SPEED_DEG_PER_SEC * dt;
    if (maxDeltaDeg < 0.1f) maxDeltaDeg = 0.1f;

    for (uint8_t leg = 0; leg < 4; leg++) {
        float modelAngles[3] = {
            targetAngles[leg].coxaDeg,
            targetAngles[leg].femurDeg,
            targetAngles[leg].tibiaDeg
        };

        for (uint8_t joint = 0; joint < 3; joint++) {
            uint8_t idx = leg * 3 + joint;

            // Convert kinematic model angle to physical servo command angle
            float cmdTarget = ServoCalibration::modelAngleToCommandAngle(idx, modelAngles[joint]);
            m_targetAngleDeg[idx] = cmdTarget;

            // Slew-rate rate limiting
            float current = m_currentAngleDeg[idx];
            float diff = cmdTarget - current;

            if (fabsf(diff) <= maxDeltaDeg) {
                current = cmdTarget;
            } else if (diff > 0.0f) {
                current += maxDeltaDeg;
            } else {
                current -= maxDeltaDeg;
            }

            m_currentAngleDeg[idx] = current;
            writeServoHardware(idx, current);
        }
    }
}

void ServoDriver::setJointAngleDirect(uint8_t jointIndex, float angleDeg) {
    if (jointIndex >= 12) return;
    const auto& cal = g_servoCalibration[jointIndex];

    float safeAngle = constrain(angleDeg, cal.minAngleDeg, cal.maxAngleDeg);
    m_targetAngleDeg[jointIndex] = safeAngle;
    m_currentAngleDeg[jointIndex] = safeAngle;
    writeServoHardware(jointIndex, safeAngle);
}

void ServoDriver::commandStandPoseDirect() {
    for (int i = 0; i < 12; i++) {
        m_targetAngleDeg[i]  = g_servoCalibration[i].centerAngleDeg;
        m_currentAngleDeg[i] = g_servoCalibration[i].centerAngleDeg;
        writeServoHardware(i, m_currentAngleDeg[i]);
    }
}

float ServoDriver::getCurrentAngle(uint8_t jointIndex) const {
    if (jointIndex >= 12) return 90.0f;
    return m_currentAngleDeg[jointIndex];
}

float ServoDriver::getTargetAngle(uint8_t jointIndex) const {
    if (jointIndex >= 12) return 90.0f;
    return m_targetAngleDeg[jointIndex];
}

void ServoDriver::writeServoHardware(uint8_t jointIndex, float angleDeg) {
    if (jointIndex >= 12 || !m_connected) return;

    uint16_t tick = ServoCalibration::angleToTicks(jointIndex, angleDeg);
    m_pwm.setPWM(g_servoCalibration[jointIndex].channel, 0, tick);
}

void ServoDriver::jogJoint(uint8_t jointIndex, float deltaDeg) {
    if (jointIndex >= 12) return;
    float newAngle = m_currentAngleDeg[jointIndex] + deltaDeg;
    setJointAngleDirect(jointIndex, newAngle);
}

void ServoDriver::setJointCenterFromCurrent(uint8_t jointIndex) {
    if (jointIndex >= 12) return;
    g_servoCalibration[jointIndex].centerAngleDeg = m_currentAngleDeg[jointIndex];
}

void ServoDriver::toggleJointDirection(uint8_t jointIndex) {
    if (jointIndex >= 12) return;
    g_servoCalibration[jointIndex].direction = -g_servoCalibration[jointIndex].direction;
}

void ServoDriver::performJointSweepTest(uint8_t jointIndex) {
    if (jointIndex >= 12 || !m_connected) return;
    const auto& cal = g_servoCalibration[jointIndex];

    Serial.print("Testing safe sweep on joint ");
    Serial.print(jointIndex);
    Serial.print(" (");
    Serial.print(cal.name);
    Serial.println(")...");

    float orig = m_currentAngleDeg[jointIndex];

    // Sweep from current to max in gentle steps
    for (float a = orig; a <= cal.maxAngleDeg; a += 1.0f) {
        setJointAngleDirect(jointIndex, a);
        delay(20);
    }
    delay(200);

    // Sweep from max to min
    for (float a = cal.maxAngleDeg; a >= cal.minAngleDeg; a -= 1.0f) {
        setJointAngleDirect(jointIndex, a);
        delay(20);
    }
    delay(200);

    // Return to original angle
    for (float a = cal.minAngleDeg; a <= orig; a += 1.0f) {
        setJointAngleDirect(jointIndex, a);
        delay(20);
    }

    Serial.println("Sweep test complete. Returned to original pose.");
}

void ServoDriver::printCalibrationTable() {
    Serial.println();
    Serial.println("==========================================================================");
    Serial.println("CURRENT SERVO CALIBRATION TABLE");
    Serial.println("==========================================================================");
    Serial.println("Idx | Ch | Joint Name | Center | Dir | Safe Min | Safe Max | CurAngle | Tick");
    Serial.println("----+----+------------+--------+-----+----------+----------+----------+-----");

    for (uint8_t i = 0; i < 12; i++) {
        const auto& c = g_servoCalibration[i];
        uint16_t tick = ServoCalibration::angleToTicks(i, m_currentAngleDeg[i]);

        char buf[128];
        snprintf(buf, sizeof(buf), " %2u | %2u | %-10s | %6.1f | %+2d  |  %6.1f  |  %6.1f  |  %6.1f  | %4u",
                 i, c.channel, c.name, c.centerAngleDeg, c.direction,
                 c.minAngleDeg, c.maxAngleDeg, m_currentAngleDeg[i], tick);
        Serial.println(buf);
    }
    Serial.println("==========================================================================");
}
