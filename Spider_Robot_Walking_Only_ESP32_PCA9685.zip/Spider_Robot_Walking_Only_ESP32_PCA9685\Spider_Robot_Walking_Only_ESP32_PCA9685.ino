/**
 * ============================================================================
 * SPIDER ROBOT: REALISTIC WALKING-ONLY CONTROLLER
 * ============================================================================
 * Hardware Target:
 *   - ESP32 DevKit
 *   - PCA9685 16-Channel PWM Servo Driver at I2C address 0x40
 *   - SDA: GPIO 21, SCL: GPIO 22
 *   - 4 legs, 3 servos per leg (Coxa, Femur, Tibia) = 12 servos total
 *   - Nominal servo PWM frequency: 50 Hz
 * 
 * Channel Mapping:
 *   - Front Left  (Leg 0) : Coxa = 0,  Femur = 1,  Tibia = 2
 *   - Front Right (Leg 1) : Coxa = 4,  Femur = 5,  Tibia = 6
 *   - Back Left   (Leg 2) : Coxa = 8,  Femur = 9,  Tibia = 10
 *   - Back Right  (Leg 3) : Coxa = 12, Femur = 13, Tibia = 14
 *   - Unused channels     : 3, 7, 11, 15
 * 
 * Strict Scope:
 *   - Walking locomotion only (no sensors, Bluetooth, Wi-Fi, cameras, IMUs, ROS).
 *   - USB Serial Monitor interface at 115200 baud.
 *   - Non-blocking real-time control loop at 50 Hz (20 ms interval).
 * ============================================================================
 */

#include <Arduino.h>
#include <Wire.h>
#include "RobotGeometry.h"
#include "CalibrationConfig.h"
#include "GaitConfig.h"
#include "Kinematics.h"
#include "GaitPlanner.h"
#include "ServoDriver.h"

// Controller instances
GaitPlanner gaitPlanner;
ServoDriver servoDriver;

// Control loop timing
uint32_t lastLoopTimeMs = 0;

// Interactive calibration mode state
bool inCalibrationMode = false;
uint8_t selectedCalibrationJoint = 0;

// Forward declarations
void printHelp();
void printStatus();
void handleNormalCommand(char cmd);
void handleCalibrationCommand(char cmd);
void printCalibrationHelp();

void setup() {
    Serial.begin(115200);
    delay(500);

    Serial.println();
    Serial.println("==================================================================");
    Serial.println("  SPIDER ROBOT: REALISTIC WALKING CONTROLLER (ESP32 + PCA9685)  ");
    Serial.println("==================================================================");
    Serial.println("Firmware: 12-Servo Standalone Walking-Only Controller");
    Serial.println("Kinematics: 3-DOF Closed-Form Leg Inverse Kinematics");
    Serial.println("Gait: Open-Loop Diagonal Trot (70% Duty) & 4-Beat Crawl (75% Duty)");
    Serial.println("Trajectory: Smooth Cosine Stance/Swing with Sinusoidal Lift Arch");
    Serial.println("Leg Links: Coxa Lc = 42.2 mm | Femur Lf = 65.4 mm | Tibia Lt = 97.5 mm");
    Serial.println("Distance Bounds: Min = 32.1 mm | Max = 162.9 mm");
    Serial.println("Safety: Slew-rate acceleration limiting & workspace clamping active");
    Serial.println("------------------------------------------------------------------");

    // Run Forward & Inverse Kinematics self-test verification
    Kinematics::runVerificationTests();

    // Initialize I2C and PCA9685
    Serial.print("Connecting to PCA9685 at I2C 0x40 (SDA=21, SCL=22)... ");
    if (servoDriver.init(21, 22, 0x40)) {
        Serial.println("[OK]");
        Serial.println("PCA9685 detected. PWM output configured to 50 Hz.");
    } else {
        Serial.println("[FAILED]");
        Serial.println("WARNING: PCA9685 did not respond at address 0x40!");
        Serial.println("Check: 1) SDA to GPIO 21, SCL to GPIO 22");
        Serial.println("       2) PCA9685 VCC connected to ESP32 3.3V, GND shared");
        Serial.println("       3) Regulated servo power supply connected to PCA9685 V+");
    }

    // Initialize gait planner
    gaitPlanner.init();

    // Command safe initial stand pose
    servoDriver.commandStandPoseDirect();
    delay(400);

    printHelp();
    printStatus();

    lastLoopTimeMs = millis();
}

void loop() {
    uint32_t currentMillis = millis();

    // Process serial input (non-blocking)
    while (Serial.available() > 0) {
        char cmd = (char)Serial.read();
        // Ignore whitespace, CR, LF
        if (cmd == '\r' || cmd == '\n' || cmd == ' ') continue;

        if (inCalibrationMode) {
            handleCalibrationCommand(cmd);
        } else {
            handleNormalCommand(cmd);
        }
    }

    // Fixed-rate control loop update (default 20 ms = 50 Hz)
    if (currentMillis - lastLoopTimeMs >= GaitConfig::CONTROL_LOOP_INTERVAL_MS) {
        float dt = (float)(currentMillis - lastLoopTimeMs) / 1000.0f;
        lastLoopTimeMs = currentMillis;

        if (!inCalibrationMode) {
            // 1. Calculate target foot positions for all 4 legs
            Vector3D footTargets[4];
            gaitPlanner.update(currentMillis, footTargets);

            // 2. Solve 3-DOF Inverse Kinematics for each leg
            LegJointAngles legAngles[4];
            for (uint8_t leg = 0; leg < 4; leg++) {
                bool reachable = Kinematics::solveIK(leg, footTargets[leg], legAngles[leg]);
                if (!reachable) {
                    // Out-of-reach targets are automatically clamped safely by Kinematics
                }
            }

            // 3. Update servos with slew-rate limiting and write to PCA9685
            servoDriver.update(dt, legAngles);
        }
    }
}

// ----------------------------------------------------------------------------
// Normal Operation Command Handler
// ----------------------------------------------------------------------------
void handleNormalCommand(char cmd) {
    switch (cmd) {
        case 'W':
        case 'w':
            gaitPlanner.cmdWalkForward();
            Serial.println(">> COMMAND: Walk Forward (W)");
            break;

        case 'B':
        case 'b':
            gaitPlanner.cmdWalkBackward();
            Serial.println(">> COMMAND: Walk Backward (B)");
            break;

        case 'A':
        case 'a':
            gaitPlanner.cmdTurnLeft();
            Serial.println(">> COMMAND: Turn Left (A)");
            break;

        case 'D':
        case 'd':
            gaitPlanner.cmdTurnRight();
            Serial.println(">> COMMAND: Turn Right (D)");
            break;

        case 'S':
        case 's':
            gaitPlanner.cmdStop();
            Serial.println(">> COMMAND: Stopping gait... smoothly transitioning to Stand pose.");
            Serial.println("   [Notice: Servos remain powered and holding position.]");
            break;

        case 'H':
        case 'h':
            gaitPlanner.cmdStand();
            Serial.println(">> COMMAND: Stand Pose (H)");
            break;

        case 'L':
        case 'l':
            gaitPlanner.cmdSit();
            Serial.println(">> COMMAND: Lower / Sit Pose (L)");
            break;

        case '+':
        case '=':
            gaitPlanner.cmdIncreaseSpeed();
            Serial.print(">> Speed Increased. Cycle period: ");
            Serial.print(gaitPlanner.getCyclePeriod(), 2);
            Serial.println(" s");
            break;

        case '-':
        case '_':
            gaitPlanner.cmdDecreaseSpeed();
            Serial.print(">> Speed Decreased. Cycle period: ");
            Serial.print(gaitPlanner.getCyclePeriod(), 2);
            Serial.println(" s");
            break;

        case 'G':
        case 'g':
            gaitPlanner.cmdToggleGait();
            Serial.print(">> Gait Toggled. Active Gait: ");
            Serial.println((gaitPlanner.getGaitType() == GaitConfig::GAIT_DIAGONAL_TROT) ? 
                           "Diagonal Trot (70% Duty)" : "4-Beat Crawl / Wave (75% Duty)");
            break;

        case 'C':
        case 'c':
            inCalibrationMode = true;
            gaitPlanner.cmdStand();
            selectedCalibrationJoint = 0;
            Serial.println();
            Serial.println(">> ENTERING SERVO CALIBRATION MODE (C)");
            Serial.println("   Gait engine paused. Individual servo jogging enabled.");
            printCalibrationHelp();
            servoDriver.printCalibrationTable();
            break;

        case 'R':
        case 'r':
            printStatus();
            break;

        case 'K':
        case 'k':
            Kinematics::runVerificationTests();
            break;

        case '?':
            printHelp();
            break;

        default:
            Serial.print("Unknown command: '");
            Serial.print(cmd);
            Serial.println("'. Send '?' for help.");
            break;
    }
}

// ----------------------------------------------------------------------------
// Calibration Mode Command Handler
// ----------------------------------------------------------------------------
void handleCalibrationCommand(char cmd) {
    switch (cmd) {
        // Joint selection: 0 through 9
        case '0': case '1': case '2': case '3': case '4':
        case '5': case '6': case '7': case '8': case '9':
            selectedCalibrationJoint = cmd - '0';
            Serial.print(">> Selected joint: ");
            Serial.print(selectedCalibrationJoint);
            Serial.print(" (");
            Serial.print(g_servoCalibration[selectedCalibrationJoint].name);
            Serial.print(") - Current Angle: ");
            Serial.println(servoDriver.getCurrentAngle(selectedCalibrationJoint), 1);
            break;

        // Joint selection shortcuts for joints 10 and 11
        case 'u': case 'U': // Joint 10 (BL Tibia)
            selectedCalibrationJoint = 10;
            Serial.print(">> Selected joint: 10 (BL Tibia) - Angle: ");
            Serial.println(servoDriver.getCurrentAngle(10), 1);
            break;

        case 'k': case 'K': // Joint 11 (BR Tibia)
            selectedCalibrationJoint = 11;
            Serial.print(">> Selected joint: 11 (BR Tibia) - Angle: ");
            Serial.println(servoDriver.getCurrentAngle(11), 1);
            break;

        // Next joint
        case 'n': case 'N':
            selectedCalibrationJoint = (selectedCalibrationJoint + 1) % 12;
            Serial.print(">> Selected joint: ");
            Serial.print(selectedCalibrationJoint);
            Serial.print(" (");
            Serial.print(g_servoCalibration[selectedCalibrationJoint].name);
            Serial.print(") - Current Angle: ");
            Serial.println(servoDriver.getCurrentAngle(selectedCalibrationJoint), 1);
            break;

        // Previous joint
        case 'p': case 'P':
            selectedCalibrationJoint = (selectedCalibrationJoint == 0) ? 11 : (selectedCalibrationJoint - 1);
            Serial.print(">> Selected joint: ");
            Serial.print(selectedCalibrationJoint);
            Serial.print(" (");
            Serial.print(g_servoCalibration[selectedCalibrationJoint].name);
            Serial.print(") - Current Angle: ");
            Serial.println(servoDriver.getCurrentAngle(selectedCalibrationJoint), 1);
            break;

        // Jog +1 deg
        case '+': case '=':
            servoDriver.jogJoint(selectedCalibrationJoint, +1.0f);
            Serial.print("Joint ");
            Serial.print(selectedCalibrationJoint);
            Serial.print(" angle: ");
            Serial.println(servoDriver.getCurrentAngle(selectedCalibrationJoint), 1);
            break;

        // Jog -1 deg
        case '-': case '_':
            servoDriver.jogJoint(selectedCalibrationJoint, -1.0f);
            Serial.print("Joint ");
            Serial.print(selectedCalibrationJoint);
            Serial.print(" angle: ");
            Serial.println(servoDriver.getCurrentAngle(selectedCalibrationJoint), 1);
            break;

        // Jog +5 deg
        case '>': case '.':
            servoDriver.jogJoint(selectedCalibrationJoint, +5.0f);
            Serial.print("Joint ");
            Serial.print(selectedCalibrationJoint);
            Serial.print(" angle: ");
            Serial.println(servoDriver.getCurrentAngle(selectedCalibrationJoint), 1);
            break;

        // Jog -5 deg
        case '<': case ',':
            servoDriver.jogJoint(selectedCalibrationJoint, -5.0f);
            Serial.print("Joint ");
            Serial.print(selectedCalibrationJoint);
            Serial.print(" angle: ");
            Serial.println(servoDriver.getCurrentAngle(selectedCalibrationJoint), 1);
            break;

        // Zero / Center capture
        case 'Z': case 'z':
            servoDriver.setJointCenterFromCurrent(selectedCalibrationJoint);
            Serial.print(">> Joint ");
            Serial.print(selectedCalibrationJoint);
            Serial.print(" NEW CENTER captured: ");
            Serial.println(g_servoCalibration[selectedCalibrationJoint].centerAngleDeg, 1);
            break;

        // Invert direction
        case 'I': case 'i':
            servoDriver.toggleJointDirection(selectedCalibrationJoint);
            Serial.print(">> Joint ");
            Serial.print(selectedCalibrationJoint);
            Serial.print(" direction toggled: ");
            Serial.println(g_servoCalibration[selectedCalibrationJoint].direction > 0 ? "+1 (Normal)" : "-1 (Inverted)");
            break;

        // Test sweep
        case 'T': case 't':
            servoDriver.performJointSweepTest(selectedCalibrationJoint);
            break;

        // View full table
        case 'V': case 'v':
            servoDriver.printCalibrationTable();
            break;

        // Exit calibration mode
        case 'X': case 'x':
        case 'Q': case 'q':
            inCalibrationMode = false;
            servoDriver.commandStandPoseDirect();
            Serial.println();
            Serial.println(">> EXITED CALIBRATION MODE. Returned to Stand Pose.");
            printHelp();
            break;

        case '?':
            printCalibrationHelp();
            break;

        default:
            Serial.print("Calibration sub-command unknown: '");
            Serial.print(cmd);
            Serial.println("'. Send '?' for calibration help.");
            break;
    }
}

// ----------------------------------------------------------------------------
// Help & Status Displays
// ----------------------------------------------------------------------------
void printHelp() {
    Serial.println();
    Serial.println("==================================================================");
    Serial.println("                     USB SERIAL COMMAND HELP                      ");
    Serial.println("==================================================================");
    Serial.println(" Locomotion Commands:");
    Serial.println("   W : Walk forward");
    Serial.println("   B : Walk backward");
    Serial.println("   A : Turn left  (differential foot stride)");
    Serial.println("   D : Turn right (differential foot stride)");
    Serial.println("   S : Stop walking (smooth ramp down to standing pose)");
    Serial.println("   H : Stand pose (neutral standing height)");
    Serial.println("   L : Lower / Sit pose (chassis lowered close to surface)");
    Serial.println();
    Serial.println(" Tuning & Configuration:");
    Serial.println("   + : Increase walking speed (shorter cycle period)");
    Serial.println("   - : Decrease walking speed (longer cycle period)");
    Serial.println("   G : Toggle gait (Diagonal Trot <-> 4-Beat Crawl)");
    Serial.println("   R : Report real-time status and telemetry");
    Serial.println("   K : Run Forward & Inverse Kinematics verification tests");
    Serial.println();
    Serial.println(" Calibration & Safety:");
    Serial.println("   C : Enter interactive 12-servo calibration mode");
    Serial.println("   ? : Display this help menu");
    Serial.println();
    Serial.println(" Safety Note: 'S' stops gait progression; servos continue holding");
    Serial.println(" position under power. To cut power, switch off servo power supply.");
    Serial.println("==================================================================");
}

void printCalibrationHelp() {
    Serial.println();
    Serial.println("------------------------------------------------------------------");
    Serial.println("                 CALIBRATION MODE COMMANDS                        ");
    Serial.println("------------------------------------------------------------------");
    Serial.println(" Joint Selection:");
    Serial.println("   0..9 : Select joint 0 to 9 directly");
    Serial.println("   U    : Select joint 10 (Back Left Tibia)");
    Serial.println("   K    : Select joint 11 (Back Right Tibia)");
    Serial.println("   N/P  : Next / Previous joint");
    Serial.println();
    Serial.println(" Jogging & Tuning:");
    Serial.println("   + / - : Jog selected joint by +1.0 / -1.0 degree");
    Serial.println("   > / < : Jog selected joint by +5.0 / -5.0 degrees");
    Serial.println("   Z     : Save current angle as NEW CENTER for selected joint");
    Serial.println("   I     : Toggle direction inversion (+1 <-> -1)");
    Serial.println("   T     : Perform gentle safe sweep test on selected joint");
    Serial.println("   V     : View full calibration table");
    Serial.println();
    Serial.println(" Exit:");
    Serial.println("   X / Q : Exit calibration mode and return to Stand pose");
    Serial.println("------------------------------------------------------------------");
}

void printStatus() {
    Serial.println();
    Serial.println("------------------------- ROBOT STATUS ---------------------------");
    Serial.print("State        : ");
    switch (gaitPlanner.getState()) {
        case STATE_STAND:         Serial.println("STAND"); break;
        case STATE_WALK_FORWARD:  Serial.println("WALK FORWARD"); break;
        case STATE_WALK_BACKWARD: Serial.println("WALK BACKWARD"); break;
        case STATE_TURN_LEFT:     Serial.println("TURN LEFT"); break;
        case STATE_TURN_RIGHT:    Serial.println("TURN RIGHT"); break;
        case STATE_SIT:           Serial.println("SIT / LOWERED"); break;
        case STATE_STOPPING:      Serial.println("STOPPING (Ramping down)"); break;
        case STATE_CALIBRATION:   Serial.println("CALIBRATION MODE"); break;
    }

    Serial.print("Gait Type    : ");
    Serial.println((gaitPlanner.getGaitType() == GaitConfig::GAIT_DIAGONAL_TROT) ?
                   "Diagonal Trot (70% Duty)" : "4-Beat Crawl (75% Duty)");

    Serial.print("Cycle Period : ");
    Serial.print(gaitPlanner.getCyclePeriod(), 2);
    Serial.println(" s");

    Serial.print("Step Length  : ");
    Serial.print(gaitPlanner.getStepLength(), 1);
    Serial.println(" mm");

    Serial.print("Step Height  : ");
    Serial.print(gaitPlanner.getStepHeight(), 1);
    Serial.println(" mm");

    Serial.print("PCA9685 I2C  : ");
    Serial.println(servoDriver.isConnected() ? "Connected (0x40)" : "DISCONNECTED / ERROR");
    Serial.println("------------------------------------------------------------------");
}
