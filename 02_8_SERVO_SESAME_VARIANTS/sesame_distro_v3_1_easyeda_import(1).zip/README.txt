SESAME DISTRO V3.1 reconstructed schematic
============================================
This is an editable KiCad legacy schematic reconstructed from the supplied
EasyEDA screenshot. It is intended for import into EasyEDA Standard.

IMPORTANT:
- This is NOT an original EasyEDA source file.
- The screenshot does not expose the full electrical/netlist metadata.
- Verify every pin number, component value, footprint, power rail and USB-C
  connection against the original design before using it for PCB fabrication.
- EasyEDA's KiCad import requires the schematic and symbol library together;
  this ZIP contains both.

Suggested EasyEDA import:
File > Open > Import KiCad, then select this ZIP.
