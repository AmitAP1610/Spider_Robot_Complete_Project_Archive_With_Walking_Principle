# QUADROPAD — Sesame Firmware Adaptation (Arranged Build)

This folder is the arranged firmware project for the current QUADROPAD hardware and the decisions made during calibration.

## Current hardware

- ESP32 DevKit / original ESP32-WROOM-32
- PCA9685 16-channel servo driver at I2C address `0x40`
- 8 × MG90S servos
- SSD1306 128×64 OLED at I2C address `0x3C`
- VL53L0X time-of-flight distance sensor
- HC-SR04 ultrasonic sensor (optional; ECHO must be level-shifted)
- 2S Li-ion battery and regulated 5 V high-current buck/BEC

## Project files

- `QUADROPAD_Sesame_PCA9685.ino` — main firmware, Wi-Fi controller, sensor setup, PCA9685 servo output
- `movement-sequences.h` — retained Sesame movement/pose routines
- `face-bitmaps.h` — retained bitmap faces
- `captive-portal.h` — phone browser controller page
- `libraries.txt` — Arduino libraries required

Keep all four source files in the same Arduino sketch folder. Open `QUADROPAD_Sesame_PCA9685.ino` in Arduino IDE.

## Servo channel mapping — do not reorder

| PCA9685 channel | Leg/servo |
|---:|---|
| CH0 | R1 |
| CH1 | R2 |
| CH2 | L1 |
| CH3 | L2 |
| CH4 | R4 |
| CH5 | R3 |
| CH6 | L3 |
| CH7 | L4 |

This matches the mapping used during the earlier channel-by-channel tests.

## I2C and sensor wiring

| ESP32 pin | Connect to |
|---|---|
| GPIO21 (SDA) | PCA9685 SDA, OLED SDA, VL53L0X SDA |
| GPIO22 (SCL) | PCA9685 SCL, OLED SCL, VL53L0X SCL |
| 3V3 | PCA9685 logic VCC; OLED/VL53L0X only if supported by the breakout |
| GND | ESP32, PCA9685 logic GND, sensors, and servo supply negative |
| GPIO5 | HC-SR04 TRIG |
| GPIO18 | HC-SR04 ECHO through a resistor divider |

For HC-SR04 ECHO, use a divider such as ECHO → 1 kΩ → GPIO18, with 2 kΩ from GPIO18 to GND. The ESP32 GPIO is not 5 V tolerant.

## Power — important

1. Battery pack (2S: 7.4 V nominal, 8.4 V fully charged) → switch → buck converter input.
2. With the servo rail disconnected, adjust the buck output to **5.0 V using a multimeter**.
3. Buck 5 V output → PCA9685 `V+` servo rail and the appropriate ESP32 VIN/5V input only if the board's power arrangement supports it.
4. All grounds must be common.
5. Never connect the raw 2S battery directly to PCA9685 `V+` or to the MG90S servos. Do not power eight servos from ESP32 3V3 or laptop USB.

Use a regulated supply sized for the actual servo load; a supply in the 5 V, 7–10 A class is a practical starting point for eight small servos, but stall current and wiring determine the real requirement.

## Phone control (Wi-Fi; this is not the Bluetooth sketch)

This firmware creates its own Wi-Fi access point:

- Network: `Sesame-Controller`
- Password: `12345678`
- Controller address: `http://192.168.4.1`

Steps:
1. Upload this firmware to the ESP32.
2. Connect the phone to Wi-Fi `Sesame-Controller` using password `12345678`. If Android says “no internet,” choose to stay connected.
3. Open a browser and visit `http://192.168.4.1`. The captive portal may open automatically.
4. Use the web controller. Bluetooth Serial commands from the separate Bluetooth sketch are not used by this firmware.

## Calibration safety mode (enabled)

Because R1 previously buzzed/strained and contacted the frame, this arranged build clamps all servo output commands to **70°–110°**, including commands coming from the browser, API, serial input, and gait functions. The boot pose is 90°.

**This is intentionally a calibration build, not yet a verified walking build.** Gait poses outside 70°–110° will be clipped and may not produce a valid walking motion. Do not test walking until every horn/linkage clears the frame throughout its full intended travel and all servos move without buzzing.

If a servo buzzes, strains, or touches the frame:
1. Turn off the external servo 5 V supply immediately.
2. Do not force the servo horn by hand while powered.
3. Inspect linkage and horn alignment with power off.
4. Re-test only after the mechanical interference is resolved.

Do not widen `SERVO_SAFE_MIN_DEG` / `SERVO_SAFE_MAX_DEG` merely to force a gait to work. Expand limits gradually only after safe mechanical travel is confirmed.

## Arduino IDE libraries

Install:
- Adafruit PWM Servo Driver Library
- Adafruit VL53L0X
- Adafruit GFX Library
- Adafruit SSD1306
- ESP32 board support package

## Useful Serial Monitor commands

Set baud rate to `115200` and use newline line endings.

- `all 90` — command all servos to neutral
- `0 90` — set servo index/channel 0 (R1) to 90°
- `subtrim 0 5` — set CH0 subtrim to +5° (still clamped to 70°–110°)
- `subtrim` — print current subtrim values
- `run stand` / `rn st` — request stand pose (limited by calibration clamp)
- `run rest` / `rn rs` — request rest pose (limited by calibration clamp)
- `run walk` — requests the walking sequence, but it is **not recommended in calibration mode**

## Notes

- This ZIP is a source project; it has not been compiled against your exact Arduino IDE/library versions in this environment.
- The firmware retains the existing Wi-Fi/web UI, OLED face system, sensor setup, and movement-sequence files. This edit adds a conservative servo angle clamp and updates the setup documentation; it does not claim the walking gait is mechanically calibrated.
