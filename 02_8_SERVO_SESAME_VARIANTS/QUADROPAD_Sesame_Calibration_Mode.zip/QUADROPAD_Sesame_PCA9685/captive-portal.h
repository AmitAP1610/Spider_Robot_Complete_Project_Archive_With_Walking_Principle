#pragma once

#include <Arduino.h>

// ======================================================================
// --- WEB INTERFACE HTML ---
// ======================================================================

const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE HTML><html>
<head>
  <title>Sesame Access Point Controller</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="UTF-8">
  <style>
    :root {
      --content-color: #ff8c42;
      --content-color-dark: #e67a30;
      --content-color-darker: #cc6b29;
      --content-color-glow: rgba(255, 140, 66, 0.3);
    }
    
    * {
      user-select: none;
      -webkit-user-select: none;
      -webkit-touch-callout: none;
    }
    
    body { 
      font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; 
      text-align: center; 
      background: linear-gradient(135deg, #0a0a0a, #1a1a2e);
      color: #e0e0e0; 
      touch-action: manipulation; 
      margin: 0;
      padding: 10px;
      overflow-x: hidden;
      box-sizing: border-box;
    }
    
    h2 { 
      margin: 10px 0 20px 0;
      color: #fff;
      font-size: 32px;
      font-weight: 600;
      text-shadow: 0 2px 4px rgba(0,0,0,0.5);
    }
    
    /* Command Queue Status */
    .command-queue {
      font-size: 12px;
      color: #888;
      margin-bottom: 20px;
    }
    .command-queue.full {
      color: #ff6b6b;
      font-weight: bold;
    }
    
    /* Section Containers */
    .sections-container {
      display: flex;
      flex-direction: column;
      gap: 15px;
      max-width: 1400px;
      margin: 0 auto;
    }
    
    .section {
      background: rgba(30, 30, 30, 0.8);
      border: 1px solid #333;
      border-radius: 16px;
      padding: 15px;
      margin: 0 auto;
      width: calc(100% - 20px);
      max-width: 450px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.3);
      box-sizing: border-box;
    }
    
    .section-title {
      font-size: 16px;
      font-weight: 600;
      color: var(--content-color);
      margin: 0 0 15px 0;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    
    /* Button Base Styles */
    button { 
      background: linear-gradient(145deg, #3a3a3a, #2a2a2a);
      border: none; 
      color: #e0e0e0; 
      padding: 15px; 
      font-size: 18px; 
      border-radius: 12px; 
      cursor: pointer; 
      box-shadow: 0 4px 8px rgba(0,0,0,0.3);
      transition: all 0.1s;
      font-weight: 500;
    }
    button:active { 
      box-shadow: 0 2px 4px rgba(0,0,0,0.3);
      transform: translateY(2px); 
    }
    
    /* D-Pad Controls */
    .dpad-container { 
      display: flex; 
      flex-direction: column;
      align-items: center;
      gap: 15px;
      width: 100%;
    }
    .dpad { 
      display: grid; 
      grid-template-columns: repeat(3, 1fr); 
      grid-template-rows: repeat(2, 1fr); 
      gap: 12px;
      width: 100%;
      max-width: 294px;
      aspect-ratio: 3 / 2;
    }
    .dpad button { 
      font-size: 35px; 
      border: 2px solid #555; 
      color: #fff;
      width: 100%;
      height: 100%;
      min-height: 70px;
    }
    .spacer { 
      visibility: hidden; 
    }
    
    /* Pose Grid */
    .grid { 
      display: grid; 
      grid-template-columns: repeat(3, 1fr); 
      gap: 10px; 
    }
    .btn-pose { 
      background: linear-gradient(145deg, var(--content-color), var(--content-color-dark));
      padding: 12px 8px;
      font-size: 15px;
    }
    .btn-pose:active { 
      background: linear-gradient(145deg, var(--content-color-dark), var(--content-color-darker));
    }
    
    /* Special Buttons */
    .btn-stop-all { 
      background: linear-gradient(145deg, #e63946, #c92a35);
      width: 100%; 
      font-size: 20px; 
      padding: 18px; 
      box-shadow: 0 6px 12px rgba(230, 57, 70, 0.4);
      border: 2px solid #ff6b6b;
      color: #fff;
      text-transform: uppercase;
      letter-spacing: 2px;
    }
    .btn-stop-all:active { 
      background: linear-gradient(145deg, #c92a35, #a8222c);
      transform: translateY(3px); 
    }
    
    .btn-settings { 
      background: linear-gradient(145deg, #555, #444);
      padding: 12px 25px;
      font-size: 16px;
    }
    
    /* Motor Controls */
    .lock-indicator {
      font-size: 11px;
      color: #ff6b6b;
      text-align: center;
      margin-top: 5px;
      display: none;
    }
    .lock-indicator.active {
      display: block;
    }
    
    .motor-controls {
      margin-top: 10px;
    }
    .motor-slider {
      margin: 15px 0;
    }
    .motor-slider label {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
      color: #aaa;
      margin-bottom: 5px;
    }
    .motor-slider input[type="range"] {
      width: 100%;
      height: 6px;
      background: #333;
      border-radius: 5px;
      outline: none;
      -webkit-appearance: none;
    }
    .motor-slider input[type="range"]::-webkit-slider-thumb {
      -webkit-appearance: none;
      width: 18px;
      height: 18px;
      background: var(--content-color);
      border-radius: 50%;
      cursor: pointer;
      box-shadow: 0 2px 6px var(--content-color-glow);
    }
    .motor-slider input[type="range"]::-moz-range-thumb {
      width: 18px;
      height: 18px;
      background: var(--content-color);
      border-radius: 50%;
      cursor: pointer;
      border: none;
      box-shadow: 0 2px 6px var(--content-color-glow);
    }
    .motor-slider input[type="range"]:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    .motor-slider input[type="range"]:disabled::-webkit-slider-thumb,
    .motor-slider input[type="range"]:disabled::-moz-range-thumb {
      background: #666;
      cursor: not-allowed;
    }
    
    /* Gamepad Status */
    .gamepad-status {
      font-size: 13px;
      padding: 8px 14px;
      border-radius: 10px;
      border: 2px solid #666;
      color: #ccc;
      background: rgba(26, 26, 26, 0.8);
      display: inline-block;
    }
    .gamepad-status.connected {
      border-color: #2ecc71;
      color: #2ecc71;
      background: rgba(46, 204, 113, 0.1);
    }
    
    /* Settings Panel */
    .settings-panel { 
      display: none; 
      position: fixed; 
      top: 0; 
      left: 0; 
      width: 100%; 
      height: 100%; 
      background: rgba(0,0,0,0.9); 
      z-index: 100; 
      backdrop-filter: blur(8px);
      overflow-y: auto;
    }
    .settings-content { 
      background: linear-gradient(145deg, #1e1e1e, #2a2a2a);
      border: 1px solid #444; 
      max-width: 400px; 
      margin: 30px auto; 
      padding: 25px; 
      border-radius: 20px; 
      text-align: left; 
      box-shadow: 0 10px 40px rgba(0,0,0,0.6); 
    }
    .settings-content h3 { 
      color: var(--content-color); 
      margin-top: 0; 
      text-align: center;
      font-size: 24px;
    }
    .settings-section {
      margin: 20px 0;
      padding: 15px;
      background: rgba(0,0,0,0.3);
      border-radius: 10px;
    }
    .settings-section h4 {
      color: var(--content-color);
      margin: 0 0 10px 0;
      font-size: 14px;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .settings-content label { 
      display: block; 
      margin-top: 12px; 
      font-weight: 500; 
      color: #ccc;
      font-size: 13px;
    }
    .settings-content input, 
    .settings-content select { 
      width: 100%; 
      padding: 10px; 
      margin-top: 5px; 
      background: #333; 
      color: #fff; 
      border: 1px solid #555; 
      border-radius: 8px; 
      box-sizing: border-box;
      font-size: 14px;
    }
    .btn-save { 
      background: linear-gradient(145deg, #2ecc71, #27ae60);
      box-shadow: 0 4px 8px rgba(46, 204, 113, 0.3);
      width: 100%; 
      margin-top: 25px; 
      color: #fff; 
    }
    .btn-close { 
      background: linear-gradient(145deg, #e74c3c, #c0392b);
      box-shadow: 0 4px 8px rgba(231, 76, 60, 0.3);
      width: 100%; 
      margin-top: 12px; 
      color: #fff; 
    }
    
    /* Desktop Layout */
    @media (min-width: 1024px) {
      body {
        padding: 15px;
      }
      .section {
        padding: 20px;
        width: 100%;
      }
      h2 {
        margin-bottom: 30px;
      }
      .command-queue {
        margin-bottom: 30px;
      }
      .sections-container {
        flex-direction: row;
        justify-content: center;
        align-items: flex-start;
        gap: 50px;
        padding: 0 20px;
      }
      .section-column {
        flex: 0 1 450px;
        display: flex;
        flex-direction: column;
        gap: 20px;
      }
      .section {
        width: 100%;
        max-width: 450px;
        margin: 0;
      }
    }
  </style>
</head>
<body>
  <h2>Sesame Controller</h2>
  <div class="command-queue" id="queueStatus">Command Queue: 0/3</div>
  
  <div class="sections-container">
    <div class="section-column">
      <!-- Movement Control Section -->
      <div class="section">
    <div class="section-title">Movement Control</div>
    <div class="dpad-container">
      <div class="dpad">
        <div class="spacer"></div>
        <button onmousedown="move('forward')" onmouseup="stop()" ontouchstart="move('forward')" ontouchend="stop()">&#9650;</button>
        <div class="spacer"></div>
        
        <button onmousedown="move('left')" onmouseup="stop()" ontouchstart="move('left')" ontouchend="stop()">&#9664;</button>
        <button onmousedown="move('backward')" onmouseup="stop()" ontouchstart="move('backward')" ontouchend="stop()">&#9660;</button>
        <button onmousedown="move('right')" onmouseup="stop()" ontouchstart="move('right')" ontouchend="stop()">&#9654;</button>
      </div>
      <button class="btn-stop-all" onclick="stop()">STOP ALL</button>
    </div>
  </div>

      <!-- Poses & Animations Section -->
      <div class="section">
        <div class="section-title">Poses & Animations</div>
        <div class="grid">
          <button class="btn-pose" onclick="pose('rest')">Rest</button>
          <button class="btn-pose" onclick="pose('stand')">Stand</button>
          <button class="btn-pose" onclick="pose('wave')">Wave</button>
          <button class="btn-pose" onclick="pose('dance')">Dance</button>
          <button class="btn-pose" onclick="pose('swim')">Swim</button>
          <button class="btn-pose" onclick="pose('point')">Point</button>
          <button class="btn-pose" onclick="pose('pushup')">Pushup</button>
          <button class="btn-pose" onclick="pose('bow')">Bow</button>
          <button class="btn-pose" onclick="pose('cute')">Cute</button>
          <button class="btn-pose" onclick="pose('freaky')">Freaky</button>
          <button class="btn-pose" onclick="pose('worm')">Worm</button>
          <button class="btn-pose" onclick="pose('shake')">Shake</button>
          <button class="btn-pose" onclick="pose('shrug')">Shrug</button>
          <button class="btn-pose" onclick="pose('dead')">Dead</button>
          <button class="btn-pose" onclick="pose('crab')">Crab</button>
        </div>
      </div>
    </div>

    <div class="section-column">
      <!-- Settings & Status Section -->
      <div class="section">
        <div class="section-title">System</div>
        <button class="btn-settings" onclick="openSettings()">Settings</button>
        <div style="margin-top: 15px;">
          <div id="gamepadStatus" class="gamepad-status">Gamepad disconnected</div>
        </div>
      </div>
    </div>
  </div>

  <div id="settingsPanel" class="settings-panel">
    <div class="settings-content">
      <h3>Settings</h3>
      
      <div class="settings-section">
        <h4>Animation Parameters</h4>
        <label>Frame Delay (ms):</label>
        <input type="number" id="frameDelay" min="1" max="1000" step="1">
        <label>Walk Cycles:</label>
        <input type="number" id="walkCycles" min="1" max="50" step="1">
      </div>

      <div class="settings-section">
        <h4>Motor Settings</h4>
        <label>Motor Current Delay (ms):</label>
        <input type="number" id="motorCurrentDelay" min="0" max="500" step="1">
        <label>Motor Speed:</label>
        <select id="motorSpeed">
          <option value="slow">Slow</option>
          <option value="medium" selected>Medium</option>
          <option value="fast">Fast</option>
        </select>
      </div>

      <div class="settings-section">
        <h4>Theme</h4>
        <label>Accent Color:</label>
        <select id="themeColor">
          <option value="#ff8c42">Orange (Default)</option>
          <option value="#66d9ef">Cyan</option>
          <option value="#a8dadc">Light Blue</option>
          <option value="#2ecc71">Green</option>
          <option value="#e74c3c">Red</option>
          <option value="#9b59b6">Purple</option>
          <option value="#f39c12">Yellow</option>
          <option value="#e91e63">Pink</option>
          <option value="custom">Custom</option>
        </select>
        <input type="color" id="customColor" value="#ff8c42" style="margin-top: 10px; display: none;">
      </div>

      <div class="settings-section">
        <h4>WiFi / Network</h4>
        <div id="wifiStatus" style="font-size:13px; color:#ccc; margin-bottom:10px;">Checking&hellip;</div>
        <label>Network:</label>
        <select id="wifiSsid">
          <option value="">&mdash; scan for networks &mdash;</option>
        </select>
        <label style="margin-top:12px;">
          <input type="checkbox" id="wifiManual" style="width:auto; margin-right:8px;" onchange="toggleManualSsid()">
          Enter name manually (hidden network)
        </label>
        <input type="text" id="wifiSsidManual" placeholder="Network name" style="display:none;">
        <label>Password:</label>
        <input type="password" id="wifiPass" placeholder="WiFi password">
        <button class="btn-settings" style="width:100%; margin-top:12px;" onclick="scanWifi()">Scan for Networks</button>
        <button class="btn-settings" style="width:100%; margin-top:8px;" onclick="connectWifi()">Connect</button>
        <div id="wifiResult" style="font-size:13px; margin-top:10px; min-height:18px;"></div>
      </div>

      <button class="btn-settings" style="width: 100%; margin-top: 20px;" onclick="openMotorControl()">Manual Motor Control</button>

      <button class="btn-save" onclick="saveSettings()">Save Settings</button>
      <button class="btn-close" onclick="closeSettings()">Close</button>
    </div>
  </div>

  <div id="motorControlPanel" class="settings-panel">
    <div class="settings-content">
      <h3>Manual Motor Control</h3>
      <div class="lock-indicator" id="lockIndicator">Locked during animations</div>
      
      <div class="settings-section">
        <div class="motor-controls">
          <div class="motor-slider">
            <label><span>S0 R1</span><span id="m1val">90&deg;</span></label>
            <input type="range" id="motor1" min="0" max="180" value="90" oninput="updateMotor(1, this.value)">
          </div>
          <div class="motor-slider">
            <label><span>S1 R2</span><span id="m2val">90&deg;</span></label>
            <input type="range" id="motor2" min="0" max="180" value="90" oninput="updateMotor(2, this.value)">
          </div>
          <div class="motor-slider">
            <label><span>S2 L1</span><span id="m3val">90&deg;</span></label>
            <input type="range" id="motor3" min="0" max="180" value="90" oninput="updateMotor(3, this.value)">
          </div>
          <div class="motor-slider">
            <label><span>S3 L2</span><span id="m4val">90&deg;</span></label>
            <input type="range" id="motor4" min="0" max="180" value="90" oninput="updateMotor(4, this.value)">
          </div>
          <div class="motor-slider">
            <label><span>S4 R4</span><span id="m5val">90&deg;</span></label>
            <input type="range" id="motor5" min="0" max="180" value="90" oninput="updateMotor(5, this.value)">
          </div>
          <div class="motor-slider">
            <label><span>S5 R3</span><span id="m6val">90&deg;</span></label>
            <input type="range" id="motor6" min="0" max="180" value="90" oninput="updateMotor(6, this.value)">
          </div>
          <div class="motor-slider">
            <label><span>S6 L3</span><span id="m7val">90&deg;</span></label>
            <input type="range" id="motor7" min="0" max="180" value="90" oninput="updateMotor(7, this.value)">
          </div>
          <div class="motor-slider">
            <label><span>S7 L4</span><span id="m8val">90&deg;</span></label>
            <input type="range" id="motor8" min="0" max="180" value="90" oninput="updateMotor(8, this.value)">
          </div>
        </div>
      </div>

      <button class="btn-close" onclick="closeMotorControl()">Close</button>
    </div>
  </div>

<script>
// Command queue management - max 3 commands
let commandQueue = 0;
const MAX_COMMANDS = 3;
let motorsLocked = false;

// Load theme on page load
document.addEventListener('DOMContentLoaded', () => {
  loadTheme();
});

function loadTheme() {
  const savedColor = localStorage.getItem('themeColor');
  if (savedColor) {
    applyTheme(savedColor);
  }
}

function applyTheme(color) {
  const root = document.documentElement;
  root.style.setProperty('--content-color', color);
  
  // Calculate darker shades
  const rgb = hexToRgb(color);
  if (rgb) {
    const dark = `rgb(${Math.max(0, rgb.r - 20)}, ${Math.max(0, rgb.g - 20)}, ${Math.max(0, rgb.b - 20)})`;
    const darker = `rgb(${Math.max(0, rgb.r - 40)}, ${Math.max(0, rgb.g - 40)}, ${Math.max(0, rgb.b - 40)})`;
    const glow = `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.3)`;
    
    root.style.setProperty('--content-color-dark', dark);
    root.style.setProperty('--content-color-darker', darker);
    root.style.setProperty('--content-color-glow', glow);
  }
}

function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null;
}

function updateQueueStatus() {
  const queueEl = document.getElementById('queueStatus');
  queueEl.textContent = `Command Queue: ${commandQueue}/${MAX_COMMANDS}`;
  if (commandQueue >= MAX_COMMANDS) {
    queueEl.classList.add('full');
  } else {
    queueEl.classList.remove('full');
  }
}

function canSendCommand() {
  return commandQueue < MAX_COMMANDS;
}

function incrementQueue() {
  commandQueue++;
  updateQueueStatus();
  setTimeout(() => {
    if (commandQueue > 0) {
      commandQueue--;
    }
    updateQueueStatus();
  }, 1000);
}

function lockMotors(duration = 3000) {
  motorsLocked = true;
  document.getElementById('lockIndicator').classList.add('active');
  for (let i = 1; i <= 8; i++) {
    const slider = document.getElementById('motor' + i);
    if (slider) slider.disabled = true;
  }
  setTimeout(() => {
    motorsLocked = false;
    document.getElementById('lockIndicator').classList.remove('active');
    for (let i = 1; i <= 8; i++) {
      const slider = document.getElementById('motor' + i);
      if (slider) slider.disabled = false;
    }
  }, duration);
}

function move(dir) { 
  if (!canSendCommand()) return;
  incrementQueue();
  fetch('/cmd?go=' + dir).catch(console.log); 
}

function stop() { 
  commandQueue = 0;
  updateQueueStatus();
  fetch('/cmd?stop=1').catch(console.log); 
}

function pose(name) { 
  if (!canSendCommand()) return;
  incrementQueue();
  lockMotors(3000);
  fetch('/cmd?pose=' + name).catch(console.log); 
}

function updateMotor(motorNum, value) {
  if (motorsLocked) return;
  document.getElementById('m' + motorNum + 'val').textContent = value + '\u00B0';
  if (!canSendCommand()) return;
  incrementQueue();
  fetch('/cmd?motor=' + motorNum + '&value=' + value).catch(console.log);
}

function openSettings() {
  loadWifiStatus();
  fetch('/getSettings').then(r => r.json()).then(data => {
    document.getElementById('frameDelay').value = data.frameDelay || 100;
    document.getElementById('walkCycles').value = data.walkCycles || 10;
    document.getElementById('motorCurrentDelay').value = data.motorCurrentDelay || 20;
    document.getElementById('motorSpeed').value = data.motorSpeed || 'medium';
    
    // Load theme settings
    const savedColor = localStorage.getItem('themeColor') || '#ff8c42';
    const colorSelect = document.getElementById('themeColor');
    const customColorInput = document.getElementById('customColor');
    
    // Check if saved color matches a preset
    let matchFound = false;
    for (let option of colorSelect.options) {
      if (option.value === savedColor) {
        colorSelect.value = savedColor;
        matchFound = true;
        break;
      }
    }
    
    if (!matchFound) {
      colorSelect.value = 'custom';
      customColorInput.value = savedColor;
      customColorInput.style.display = 'block';
    }
    
    document.getElementById('settingsPanel').style.display = 'block';
  }).catch(() => {
    // Fallback if settings endpoint doesn't exist yet
    document.getElementById('frameDelay').value = 100;
    document.getElementById('walkCycles').value = 10;
    document.getElementById('motorCurrentDelay').value = 20;
    
    const savedColor = localStorage.getItem('themeColor') || '#ff8c42';
    document.getElementById('themeColor').value = savedColor;
    
    document.getElementById('settingsPanel').style.display = 'block';
  });
  
  // Add event listener for theme color change
  document.getElementById('themeColor').addEventListener('change', function() {
    const customColorInput = document.getElementById('customColor');
    if (this.value === 'custom') {
      customColorInput.style.display = 'block';
    } else {
      customColorInput.style.display = 'none';
      applyTheme(this.value);
    }
  });
  
  document.getElementById('customColor').addEventListener('input', function() {
    applyTheme(this.value);
  });
}

function closeSettings() { 
  document.getElementById('settingsPanel').style.display = 'none'; 
}

function openMotorControl() {
  document.getElementById('motorControlPanel').style.display = 'block';
}

function closeMotorControl() {
  document.getElementById('motorControlPanel').style.display = 'none';
}

function saveSettings() {
  const fd = document.getElementById('frameDelay').value;
  const wc = document.getElementById('walkCycles').value;
  const mcd = document.getElementById('motorCurrentDelay').value;
  const ms = document.getElementById('motorSpeed').value;
  
  // Save theme color
  const colorSelect = document.getElementById('themeColor');
  const customColorInput = document.getElementById('customColor');
  const themeColor = colorSelect.value === 'custom' ? customColorInput.value : colorSelect.value;
  localStorage.setItem('themeColor', themeColor);
  applyTheme(themeColor);
  
  fetch(`/setSettings?frameDelay=${fd}&walkCycles=${wc}&motorCurrentDelay=${mcd}&motorSpeed=${ms}`)
    .then(() => closeSettings())
    .catch(() => closeSettings());
}

function toggleManualSsid() {
  const manual = document.getElementById('wifiManual').checked;
  document.getElementById('wifiSsidManual').style.display = manual ? 'block' : 'none';
  document.getElementById('wifiSsid').style.display = manual ? 'none' : 'block';
}

// Builds "http://<host> (<ip>)" as safe DOM nodes (no innerHTML — SSIDs/values
// are untrusted and could carry markup).
function appendRobotLink(parent, host, ip) {
  const a = document.createElement('a');
  a.href = 'http://' + host;
  a.textContent = 'http://' + host;
  a.style.color = 'var(--content-color)';
  parent.appendChild(a);
  parent.appendChild(document.createTextNode(' (' + ip + ')'));
}

// Appends "http://<host> (<ip>)" — or just the raw IP when the robot reports
// its mDNS responder didn't start — as safe DOM nodes.
function appendRobotAddress(parent, d) {
  if (d.mdns) {
    appendRobotLink(parent, d.host, d.ip);
  } else {
    parent.appendChild(document.createTextNode('http://' + d.ip));
  }
}

function loadWifiStatus() {
  fetch('/api/wifi/status').then(r => r.json()).then(d => {
    const el = document.getElementById('wifiStatus');
    el.textContent = '';
    if (d.connected) {
      el.appendChild(document.createTextNode('Connected to '));
      const b = document.createElement('b');
      b.textContent = d.ssid;            // textContent: SSID is untrusted
      el.appendChild(b);
      el.appendChild(document.createTextNode(' — '));
      appendRobotAddress(el, d);
    } else if (d.connecting) {
      el.textContent = 'Connecting…';
    } else {
      el.textContent = 'Not connected (Access Point mode only).';
    }
  }).catch(() => {
    document.getElementById('wifiStatus').textContent = 'Status unavailable.';
  });
}

// The scan runs asynchronously on the robot: /api/wifi/scan answers
// {"scanning":true} until results are ready, so poll about once a second.
function scanWifi() {
  document.getElementById('wifiResult').textContent = 'Scanning…';
  pollWifiScan(0);
}

function pollWifiScan(attempt) {
  const sel = document.getElementById('wifiSsid');
  const result = document.getElementById('wifiResult');
  fetch('/api/wifi/scan').then(r => r.json()).then(data => {
    if (!Array.isArray(data)) {
      if (attempt < 20) setTimeout(() => pollWifiScan(attempt + 1), 1000);
      else result.textContent = 'Scan timed out.';
      return;
    }
    // Map (not {}): SSIDs are untrusted and may collide with
    // Object.prototype keys ('constructor', '__proto__', ...).
    const best = new Map();
    data.forEach(n => {
      if (!n.ssid) return;
      if (!best.has(n.ssid) || n.rssi > best.get(n.ssid).rssi) best.set(n.ssid, n);
    });
    const nets = Array.from(best.values()).sort((a, b) => b.rssi - a.rssi);
    sel.textContent = '';
    const ph = document.createElement('option');
    ph.value = '';
    ph.textContent = '— select network —';
    sel.appendChild(ph);
    nets.forEach(n => {
      const pct = Math.min(100, Math.max(0, 2 * (n.rssi + 100)));
      const opt = document.createElement('option');
      opt.value = n.ssid;
      opt.textContent = n.ssid + ' (' + pct + '%' + (n.secure ? ' 🔒' : '') + ')';
      sel.appendChild(opt);
    });
    result.textContent = nets.length ? (nets.length + ' networks found.') : 'No networks found.';
  }).catch(() => {
    // Transient AP hiccup — retry on the same schedule.
    if (attempt < 20) setTimeout(() => pollWifiScan(attempt + 1), 1000);
    else result.textContent = 'Scan failed.';
  });
}

// POST starts the attempt; the robot connects in the background (its access
// point may briefly drop while it changes WiFi channel), so the outcome is
// read by polling /api/wifi/status — which also survives that brief drop.
function connectWifi() {
  const manual = document.getElementById('wifiManual').checked;
  const ssid = manual ? document.getElementById('wifiSsidManual').value.trim()
                      : document.getElementById('wifiSsid').value;
  const pass = document.getElementById('wifiPass').value;
  const result = document.getElementById('wifiResult');
  if (!ssid) { result.textContent = 'Please select or enter a network.'; return; }
  result.textContent = 'Connecting to ' + ssid + '… (can take ~15s)';
  const body = 'ssid=' + encodeURIComponent(ssid) + '&password=' + encodeURIComponent(pass);
  fetch('/api/wifi/connect', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body
  }).then(r => r.json()).then(d => {
    if (d.success) {
      setTimeout(() => pollWifiConnect(0), 1500);
    } else {
      result.textContent = 'Failed: ' + (d.error || 'could not start connection') + '.';
    }
  }).catch(() => {
    // The request may have been cut off mid-flight; the attempt is most
    // likely still running on the robot, so poll for the outcome anyway.
    setTimeout(() => pollWifiConnect(0), 1500);
  });
}

function pollWifiConnect(attempt) {
  const result = document.getElementById('wifiResult');
  fetch('/api/wifi/status').then(r => r.json()).then(d => {
    if (d.connected) {
      result.textContent = 'Connected! Reach the robot at ';
      appendRobotAddress(result, d);
      loadWifiStatus();
      return;
    }
    if (d.connecting) {
      if (attempt < 30) setTimeout(() => pollWifiConnect(attempt + 1), 1000);
      else result.textContent = 'Still trying… reopen Settings to check the status.';
      return;
    }
    result.textContent = 'Failed: ' + (d.lastError || 'could not connect') +
      '. Check the password and that it is a 2.4GHz network.';
  }).catch(() => {
    // The phone may be rejoining the robot's AP after a channel change.
    if (attempt < 30) setTimeout(() => pollWifiConnect(attempt + 1), 1000);
    else result.textContent = 'Lost contact with the robot. Rejoin its WiFi network and reopen Settings.';
  });
}

let activeGamepadIndex = null;
let gamepadPollId = null;
let lastButtonStates = [];
let lastAxisDir = { x: 0, y: 0 };
const axisThreshold = 0.5;
const pollIntervalMs = 80;

const buttonBindings = {
  0: () => pose('stand'),   // A / Cross
  1: () => pose('wave'),    // B / Circle
  2: () => pose('dance'),   // X / Square
  3: () => pose('swim'),    // Y / Triangle
  4: () => pose('point'),   // LB / L1
  5: () => pose('pushup'),  // RB / R1
  6: () => pose('bow'),     // LT / L2
  7: () => pose('shake'),   // RT / R2
  8: () => stop(),          // Back / Share
  9: () => pose('rest'),    // Start / Options
  10: () => pose('cute'),   // L3
  11: () => pose('freaky'), // R3
  12: () => move('forward'),// D-pad up
  13: () => move('backward'),// D-pad down
  14: () => move('left'),   // D-pad left
  15: () => move('right'),  // D-pad right
  16: () => stop(),         // Home / PS
  17: () => pose('worm')    // Touchpad / extra
};

const buttonReleaseStop = new Set([12, 13, 14, 15]);

function updateGamepadStatus(connected) {
  const status = document.getElementById('gamepadStatus');
  if (!status) return;
  if (connected) {
    status.textContent = 'Gamepad connected';
    status.classList.add('connected');
  } else {
    status.textContent = 'Gamepad disconnected';
    status.classList.remove('connected');
  }
}

function handleButtonChange(index, pressed) {
  if (pressed) {
    const action = buttonBindings[index];
    if (action) action();
  } else if (buttonReleaseStop.has(index)) {
    stop();
  }
}

function getAxisDirection(x, y) {
  if (Math.abs(x) < axisThreshold && Math.abs(y) < axisThreshold) return { x: 0, y: 0 };
  if (Math.abs(x) > Math.abs(y)) {
    return { x: x > 0 ? 1 : -1, y: 0 };
  }
  return { x: 0, y: y > 0 ? 1 : -1 };
}

function applyAxisDirection(dir) {
  if (dir.x === 1) move('right');
  else if (dir.x === -1) move('left');
  else if (dir.y === 1) move('backward');
  else if (dir.y === -1) move('forward');
  else stop();
}

function pollGamepad() {
  const pads = navigator.getGamepads ? navigator.getGamepads() : [];
  const pad = pads && activeGamepadIndex !== null ? pads[activeGamepadIndex] : null;
  if (!pad) {
    updateGamepadStatus(false);
    return;
  }
  updateGamepadStatus(true);

  if (!lastButtonStates.length) {
    lastButtonStates = pad.buttons.map(b => !!b.pressed);
  }
  pad.buttons.forEach((btn, i) => {
    const pressed = !!btn.pressed;
    if (pressed !== lastButtonStates[i]) {
      handleButtonChange(i, pressed);
      lastButtonStates[i] = pressed;
    }
  });

  const x = pad.axes[0] || 0;
  const y = pad.axes[1] || 0;
  const dir = getAxisDirection(x, y);
  if (dir.x !== lastAxisDir.x || dir.y !== lastAxisDir.y) {
    applyAxisDirection(dir);
    lastAxisDir = dir;
  }
}

window.addEventListener('gamepadconnected', (e) => {
  activeGamepadIndex = e.gamepad.index;
  lastButtonStates = [];
  lastAxisDir = { x: 0, y: 0 };
  updateGamepadStatus(true);
  if (!gamepadPollId) {
    gamepadPollId = setInterval(pollGamepad, pollIntervalMs);
  }
});

window.addEventListener('gamepaddisconnected', (e) => {
  if (activeGamepadIndex === e.gamepad.index) {
    activeGamepadIndex = null;
    lastButtonStates = [];
    lastAxisDir = { x: 0, y: 0 };
    updateGamepadStatus(false);
  }
});

if (navigator.getGamepads) {
  setInterval(() => {
    if (activeGamepadIndex !== null) return;
    const pads = navigator.getGamepads();
    if (!pads) return;
    for (let i = 0; i < pads.length; i++) {
      if (pads[i]) {
        activeGamepadIndex = pads[i].index;
        updateGamepadStatus(true);
        if (!gamepadPollId) {
          gamepadPollId = setInterval(pollGamepad, pollIntervalMs);
        }
        break;
      }
    }
  }, 1000);
}
</script>
<div style="max-width:450px;margin:20px auto;padding:14px;background:#202030;border-radius:12px">
<h3 style="color:#ff8c42">Servo Calibration</h3>
<p>Open the dedicated calibration page to move one servo at a time and save its safe range.</p>
<a href="/cal" style="display:block;background:#ff8c42;color:#111;padding:14px;border-radius:10px;text-decoration:none;font-weight:bold">Open Servo Calibration</a>
</div>
</body>
</html>
)rawliteral";
