# QUADROPAD — ESP32 + PCA9685 + VL53L0X

This is the ESP32 version of the Sesame-derived QUADROPAD firmware.

## Hardware
- ESP32 DevKit
- PCA9685 at 0x40
- 8 x MG90S on CH0–CH7
- SSD1306 128x64 at 0x3C
- VL53L0X at 0x29
- 2S battery -> regulated 5V buck/BEC

## I2C
- SDA GPIO21
- SCL GPIO22

## Servo mapping
CH0 R1
CH1 R2
CH2 L1
CH3 L2
CH4 R4
CH5 R3
CH6 L3
CH7 L4

## Power
2S battery -> switch -> 5V buck.
Buck 5V -> PCA9685 V+ and ESP32 5V/VIN.
Buck GND -> common GND.
PCA9685 VCC -> ESP32 3.3V.
Never put 7.4–8.4V directly on the 5V rail.

## Obstacle sensor
VL53L0X ONLY. HC-SR04 is not part of this firmware.
Threshold = 30 cm.

## First power-up
1. Disconnect all 8 servos.
2. Upload the sketch.
3. Serial Monitor = 115200.
4. Run `i2c` and expect 0x3C, 0x40 and 0x29.
5. Run `distance` and confirm a distance reading.
6. Connect one servo to CH0.
7. Test `0 90`.
8. Test the remaining channels one at a time.

## Wi-Fi
SSID: Sesame-Controller
Password: 12345678
IP: 192.168.4.1
mDNS: sesame-robot.local

No internet is expected while connected directly to the robot AP.

## Required Arduino libraries
- Adafruit PWM Servo Driver Library
- Adafruit VL53L0X
- Adafruit GFX Library
- Adafruit SSD1306
