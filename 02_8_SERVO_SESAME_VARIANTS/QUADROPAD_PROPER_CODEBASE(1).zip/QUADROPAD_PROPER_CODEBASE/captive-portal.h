#pragma once

// Minimal captive-portal page for the ESP32 QUADROPAD.
// Movement, status and autonomous control are handled by the firmware API.
static const char index_html[] PROGMEM = R"HTML(
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>QUADROPAD Controller</title>
<style>
body{font-family:Arial,sans-serif;background:#111;color:#fff;text-align:center;margin:20px}
button{font-size:18px;margin:5px;padding:14px 20px;border:0;border-radius:10px}
.stop{background:#c62828;color:#fff}.auto{background:#1565c0;color:#fff}
.grid{display:grid;grid-template-columns:repeat(3,1fr);max-width:430px;margin:20px auto}
.card{padding:12px;border:1px solid #555;border-radius:10px;margin:10px auto;max-width:430px}
</style>
</head>
<body>
<h1>QUADROPAD</h1>
<div class="card" id="status">Loading...</div>
<div class="grid">
<button onclick="cmd('forward')">FORWARD</button>
<button onclick="cmd('stand')">STAND</button>
<button onclick="cmd('backward')">BACK</button>
<button onclick="cmd('left')">LEFT</button>
<button class="stop" onclick="cmd('stop')">STOP</button>
<button onclick="cmd('right')">RIGHT</button>
</div>
<button class="auto" onclick="cmd('auto')">AUTONOMOUS</button><br>
<button onclick="cmd('rest')">REST</button>
<button onclick="cmd('wave')">WAVE</button>
<button onclick="cmd('dance')">DANCE</button>
<button onclick="cmd('bow')">BOW</button>
<button onclick="cmd('cute')">CUTE</button>
<button onclick="cmd('pushup')">PUSHUP</button>
<button onclick="cmd('crab')">CRAB</button>
<script>
async function cmd(c){await fetch('/api/command',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({command:c})});}
async function refresh(){try{const r=await fetch('/api/status');const s=await r.json();document.getElementById('status').innerHTML='VL53L0X: '+(s.vl53Available?'OK':'NOT DETECTED')+'<br>Mode: '+(s.autonomous?'AUTO':'MANUAL')+'<br>Face: '+s.currentFace;}catch(e){}}
refresh();setInterval(refresh,1000);
</script>
</body>
</html>
)HTML";
