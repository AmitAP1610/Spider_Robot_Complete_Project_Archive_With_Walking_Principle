# QUADROPAD — Sesame Firmware Adaptation

This project adapts the supplied Sesame Robot firmware to the current hardware:

- ESP32 DevKit
- PCA9685 16-channel servo driver
- 8 × MG90S servos
- 0.96-inch SSD1306 128×64 OLED
- VL53L0X ToF distance sensor
- HC-SR04 ultrasonic sensor
- 2S Li-ion battery + 5 V high-current buck/BEC

## What was preserved

The original Sesame movement and expression system is retained:

- `movement-sequences.h` — original pose/gait routines and servo naming/order
- `face-bitmaps.h` — original bitmap face library
- `captive-portal.h` — original web controller UI
- Wi-Fi AP, captive portal, REST/JSON command interface, idle/blink logic

## What was changed

Only the hardware-output/perception layer was adapted:

1. ESP32 direct `ESP32Servo` output was replaced by PCA9685 I²C PWM.
2. Current I²C pins are GPIO21 (SDA) and GPIO22 (SCL).
3. Eight servo channels are PCA9685 CH0–CH7.
4. VL53L0X and HC-SR04 were added for obstacle detection.
5. Forward walking is safety-stopped when an obstacle is detected within 30 cm.

## Servo channel mapping

| PCA9685 | Sesame name |
|---:|---|
| CH0 | R1 |
| CH1 | R2 |
| CH2 | L1 |
| CH3 | L2 |
| CH4 | R4 |
| CH5 | R3 |
| CH6 | L3 |
| CH7 | L4 |

Each MG90S:
- Brown/black → PCA9685 GND
- Red → PCA9685 V+
- Orange/yellow → PCA9685 channel signal

## ESP32 connections

| ESP32 | Device | Pin |
|---|---|---|
| GPIO21 | PCA9685 SDA | SDA |
| GPIO21 | VL53L0X SDA | SDA |
| GPIO21 | OLED SDA | SDA |
| GPIO22 | PCA9685 SCL | SCL |
| GPIO22 | VL53L0X SCL | SCL |
| GPIO22 | OLED SCL | SCL |
| 3.3V | PCA9685 VCC | VCC |
| 3.3V | OLED VCC | VCC |
| 3.3V | VL53L0X VCC | VCC* |
| GND | all modules | GND |
| GPIO5 | HC-SR04 | TRIG |
| GPIO18 | HC-SR04 | ECHO through divider |

`*` Use the voltage specified by your VL53L0X breakout board. Many breakouts accept 2.6–5.5 V, while bare modules do not.

### HC-SR04 echo protection

Use a resistor divider before ESP32 GPIO18, for example:

`HC-SR04 ECHO → 1 kΩ → GPIO18 → 2 kΩ → GND`

HC-SR04 VCC → 5 V.

## Power

Battery (2S, 7.4 V nominal / 8.4 V full) → switch → 5 V high-current buck/BEC.

The 5 V output powers:
- PCA9685 servo V+ rail
- ESP32 5V/VIN
- HC-SR04

All grounds must be common.

Do **not** power the eight MG90S servos from the ESP32 3.3 V rail.

## Arduino IDE libraries

Install:

- Adafruit PWM Servo Driver Library
- Adafruit VL53L0X
- Adafruit GFX Library
- Adafruit SSD1306

ESP32 board support must also be installed.

## First test

1. Keep the robot lifted off the floor.
2. Upload the sketch.
3. Open Serial Monitor at 115200.
4. Confirm `VL53L0X detected.` if the sensor is connected.
5. Use the web controller or serial commands to test individual channels.
6. Verify each servo's mechanical direction before putting the robot on the ground.

### Serial examples

- `0 90` — servo channel/index 0 to 90°
- `all 90` — all 8 servos to 90°
- `run stand` — stand pose
- `run rest` — rest pose
- `run walk` — forward gait
- `rn tl` — turn left
- `rn tr` — turn right
- `face happy` — select a face
- `subtrim 0 5` — add +5° trim to servo index 0

## Important calibration note

The original Sesame code uses a direct-servo range of approximately 732–2929 µs. The PCA9685 adaptation maps that range to approximately 150–600 ticks at 50 Hz. Mechanical servo orientation is still hardware-dependent, so use the built-in subtrim and individual-servo controls before walking.
