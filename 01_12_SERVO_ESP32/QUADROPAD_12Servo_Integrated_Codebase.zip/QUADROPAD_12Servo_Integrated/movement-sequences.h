#pragma once
#include <Arduino.h>

enum FaceAnimMode : uint8_t { FACE_ANIM_LOOP=0, FACE_ANIM_ONCE=1, FACE_ANIM_BOOMERANG=2 };

// Logical channel order: FL coxa/femur/tibia, FR coxa/femur/tibia,
// BL coxa/femur/tibia, BR coxa/femur/tibia.
static const uint8_t FL_COXA=0, FL_FEMUR=1, FL_TIBIA=2;
static const uint8_t FR_COXA=3, FR_FEMUR=4, FR_TIBIA=5;
static const uint8_t BL_COXA=6, BL_FEMUR=7, BL_TIBIA=8;
static const uint8_t BR_COXA=9, BR_FEMUR=10, BR_TIBIA=11;

extern int frameDelay;
extern int walkCycles;
extern String currentCommand;
extern void setServoAngle(uint8_t channel, int angle);
extern void setFace(const String& faceName);
extern void setFaceMode(FaceAnimMode mode);
extern void setFaceWithMode(const String& faceName, FaceAnimMode mode);
extern void delayWithFace(unsigned long ms);
extern void enterIdle();
extern bool pressingCheck(String cmd, int ms);
extern bool obstacleAhead();

void runRestPose(); void runStandPose(int face=1); void runSitPose(); void runLegTest(uint8_t leg); void runWavePose();
void runDancePose(); void runSwimPose(); void runPointPose(); void runPushupPose();
void runBowPose(); void runCutePose(); void runFreakyPose(); void runWormPose();
void runShakePose(); void runShrugPose(); void runDeadPose(); void runCrabPose();
void runWalkPose(); void runWalkBackward(); void runTurnLeft(); void runTurnRight();

inline void spiderNeutral() { for (uint8_t ch=0; ch<12; ch++) setServoAngle(ch,90); }
inline void runRestPose() { setFaceWithMode("rest",FACE_ANIM_BOOMERANG); spiderNeutral(); if(currentCommand=="rest") currentCommand=""; }
inline void runStandPose(int face) { if(face) setFaceWithMode("stand",FACE_ANIM_ONCE); spiderNeutral(); if(face) enterIdle(); if(currentCommand=="stand") currentCommand=""; }
inline void runSitPose() { setFaceWithMode("rest",FACE_ANIM_ONCE); for(uint8_t leg=0;leg<4;leg++){uint8_t b=leg*3;setServoAngle(b,90);setServoAngle(b+1,78);setServoAngle(b+2,78);} if(currentCommand=="sit") currentCommand=""; }
inline void runLegTest(uint8_t leg) {
  if (leg >= 4) return;
  setFaceWithMode("thinking", FACE_ANIM_ONCE);
  uint8_t base = leg * 3;
  for (uint8_t joint=0; joint<3 && currentCommand == String("test") + String(leg); joint++) {
    setServoAngle(base+joint, 80); delayWithFace(350);
    if (currentCommand != String("test") + String(leg)) break;
    setServoAngle(base+joint, 100); delayWithFace(350);
    if (currentCommand != String("test") + String(leg)) break;
    setServoAngle(base+joint, 90); delayWithFace(250);
  }
  if (currentCommand == String("test") + String(leg)) currentCommand = "";
}

// Diagonal-pair step demo. Angles are intentionally constrained by setServoAngle().
inline void stepPair(uint8_t a, uint8_t b, int lift, int swing, String cmd) {
  setServoAngle(a*3+1,lift); setServoAngle(b*3+1,lift);
  if(!pressingCheck(cmd,frameDelay)) return;
  setServoAngle(a*3,swing); setServoAngle(b*3,180-swing);
  if(!pressingCheck(cmd,frameDelay)) return;
  setServoAngle(a*3+1,90); setServoAngle(b*3+1,90);
  if(!pressingCheck(cmd,frameDelay)) return;
  setServoAngle(a*3,90); setServoAngle(b*3,90);
}
inline void runWalkPose() {
  setFaceWithMode("walk",FACE_ANIM_LOOP);
  int cycles=constrain(walkCycles,1,20);
  for(int i=0;i<cycles && currentCommand=="forward";i++) {
    if(obstacleAhead()) { currentCommand=""; runStandPose(0); setFaceWithMode("surprised",FACE_ANIM_ONCE); return; }
    stepPair(0,3,100,80,"forward"); if(currentCommand!="forward") break;
    stepPair(1,2,100,100,"forward");
  }
  if(currentCommand=="forward") currentCommand="";
  runStandPose(1);
}
inline void runWalkBackward() {
  setFaceWithMode("walk",FACE_ANIM_LOOP);
  int cycles=constrain(walkCycles,1,20);
  for(int i=0;i<cycles && currentCommand=="backward";i++) {
    stepPair(0,3,100,100,"backward"); if(currentCommand!="backward") break;
    stepPair(1,2,100,80,"backward");
  }
  if(currentCommand=="backward") currentCommand=""; runStandPose(1);
}
inline void runTurnLeft() {
  setFaceWithMode("walk",FACE_ANIM_LOOP);
  for(int i=0;i<constrain(walkCycles,1,10) && currentCommand=="left";i++) {
    setServoAngle(FL_FEMUR,100); setServoAngle(BR_FEMUR,100); delayWithFace(frameDelay);
    setServoAngle(FL_COXA,80); setServoAngle(BR_COXA,80); delayWithFace(frameDelay);
    setServoAngle(FR_FEMUR,100); setServoAngle(BL_FEMUR,100); delayWithFace(frameDelay);
    setServoAngle(FR_COXA,100); setServoAngle(BL_COXA,100); delayWithFace(frameDelay);
  }
  if(currentCommand=="left") currentCommand=""; runStandPose(1);
}
inline void runTurnRight() {
  setFaceWithMode("walk",FACE_ANIM_LOOP);
  for(int i=0;i<constrain(walkCycles,1,10) && currentCommand=="right";i++) {
    setServoAngle(FL_FEMUR,100); setServoAngle(BR_FEMUR,100); delayWithFace(frameDelay);
    setServoAngle(FL_COXA,100); setServoAngle(BR_COXA,100); delayWithFace(frameDelay);
    setServoAngle(FR_FEMUR,100); setServoAngle(BL_FEMUR,100); delayWithFace(frameDelay);
    setServoAngle(FR_COXA,80); setServoAngle(BL_COXA,80); delayWithFace(frameDelay);
  }
  if(currentCommand=="right") currentCommand=""; runStandPose(1);
}
inline void runWavePose(){setFaceWithMode("wave",FACE_ANIM_ONCE);setServoAngle(FR_FEMUR,100);for(int i=0;i<3&&currentCommand=="wave";i++){setServoAngle(FR_TIBIA,100);delayWithFace(250);setServoAngle(FR_TIBIA,80);delayWithFace(250);}runStandPose(1);if(currentCommand=="wave")currentCommand="";}
inline void runDancePose(){setFaceWithMode("dance",FACE_ANIM_LOOP);for(int i=0;i<4&&currentCommand=="dance";i++){setServoAngle(FL_FEMUR,100);setServoAngle(BR_FEMUR,100);delayWithFace(250);spiderNeutral();setServoAngle(FR_FEMUR,100);setServoAngle(BL_FEMUR,100);delayWithFace(250);spiderNeutral();}runStandPose(1);if(currentCommand=="dance")currentCommand="";}
inline void runSwimPose(){setFaceWithMode("swim",FACE_ANIM_ONCE);for(int i=0;i<3&&currentCommand=="swim";i++){setServoAngle(FL_FEMUR,100);setServoAngle(FR_FEMUR,100);delayWithFace(300);setServoAngle(BL_FEMUR,100);setServoAngle(BR_FEMUR,100);delayWithFace(300);spiderNeutral();}runStandPose(1);if(currentCommand=="swim")currentCommand="";}
inline void runPointPose(){setFaceWithMode("point",FACE_ANIM_ONCE);setServoAngle(FR_FEMUR,100);setServoAngle(FR_TIBIA,100);delayWithFace(1200);runStandPose(1);if(currentCommand=="point")currentCommand="";}
inline void runPushupPose(){setFaceWithMode("pushup",FACE_ANIM_ONCE);for(int i=0;i<3&&currentCommand=="pushup";i++){for(int l=0;l<4;l++)setServoAngle(l*3+1,80);delayWithFace(400);spiderNeutral();delayWithFace(400);}runStandPose(1);if(currentCommand=="pushup")currentCommand="";}
inline void runBowPose(){setFaceWithMode("bow",FACE_ANIM_ONCE);for(uint8_t l=0;l<4;l++){setServoAngle(l*3+1,80);setServoAngle(l*3+2,80);}delayWithFace(800);runStandPose(1);if(currentCommand=="bow")currentCommand="";}
inline void runCutePose(){setFaceWithMode("cute",FACE_ANIM_ONCE);setServoAngle(FL_FEMUR,100);setServoAngle(FL_TIBIA,100);setServoAngle(FR_FEMUR,80);delayWithFace(700);runStandPose(1);if(currentCommand=="cute")currentCommand="";}
inline void runFreakyPose(){setFaceWithMode("freaky",FACE_ANIM_ONCE);for(int i=0;i<3&&currentCommand=="freaky";i++){setServoAngle(BR_FEMUR,100);delayWithFace(250);setServoAngle(BR_FEMUR,80);delayWithFace(250);}runStandPose(1);if(currentCommand=="freaky")currentCommand="";}
inline void runWormPose(){setFaceWithMode("worm",FACE_ANIM_ONCE);for(int i=0;i<3&&currentCommand=="worm";i++){setServoAngle(FL_FEMUR,100);setServoAngle(BR_FEMUR,80);delayWithFace(300);setServoAngle(FL_FEMUR,80);setServoAngle(BR_FEMUR,100);delayWithFace(300);}runStandPose(1);if(currentCommand=="worm")currentCommand="";}
inline void runShakePose(){setFaceWithMode("shake",FACE_ANIM_ONCE);for(int i=0;i<3&&currentCommand=="shake";i++){setServoAngle(FL_FEMUR,100);setServoAngle(FR_FEMUR,100);delayWithFace(250);setServoAngle(FL_FEMUR,80);setServoAngle(FR_FEMUR,80);delayWithFace(250);}runStandPose(1);if(currentCommand=="shake")currentCommand="";}
inline void runShrugPose(){setFaceWithMode("shrug",FACE_ANIM_ONCE);setServoAngle(FL_FEMUR,100);setServoAngle(FR_FEMUR,100);delayWithFace(1000);runStandPose(1);if(currentCommand=="shrug")currentCommand="";}
inline void runDeadPose(){setFaceWithMode("dead",FACE_ANIM_BOOMERANG);spiderNeutral();if(currentCommand=="dead")currentCommand="";}
inline void runCrabPose(){setFaceWithMode("crab",FACE_ANIM_ONCE);for(int i=0;i<3&&currentCommand=="crab";i++){setServoAngle(FL_COXA,80);setServoAngle(BL_COXA,80);setServoAngle(FR_COXA,100);setServoAngle(BR_COXA,100);delayWithFace(300);spiderNeutral();delayWithFace(300);}runStandPose(1);if(currentCommand=="crab")currentCommand="";}
