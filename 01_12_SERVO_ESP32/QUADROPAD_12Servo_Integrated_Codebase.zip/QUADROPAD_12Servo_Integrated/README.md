# QUADROPAD 12-Servo Integrated Firmware

This project combines the 12-servo spider robot controller with the prior Sesame-style firmware features: OLED bitmap faces, Wi-Fi AP web controller, serial control, VL53L0X and HC-SR04 distance reading, movement poses, and persistent per-servo trim/safe limits.

## Hardware assumptions
- ESP32 DevKit (classic ESP32), I2C SDA GPIO21 and SCL GPIO22
- PCA9685 at address 0x40, servo signal outputs 0,1,2 / 4,5,6 / 8,9,10 / 12,13,14
- SSD1306 128x64 OLED at 0x3C
- Optional VL53L0X at the same I2C bus (address 0x29)
- Optional HC-SR04 TRIG GPIO5, ECHO GPIO18. Use a voltage divider/level shifter on ECHO because ESP32 GPIO is 3.3V only.
- External regulated servo supply to PCA9685 V+; share ground with ESP32. Do not power servos from 3V3.

## Setup
1. Open `QUADROPAD_12Servo_Integrated.ino` in Arduino IDE (the folder and main `.ino` filename should match).
2. Install the libraries listed in `libraries.txt`.
3. Select `ESP32 Dev Module`, correct COM port, and upload.
4. Connect phone/laptop to Wi-Fi `Sesame-Controller`, password `12345678`, then open `http://192.168.4.1`.
5. Serial Monitor uses 115200 baud. Commands: `help`, `test0`..`test3`, `0 90` through `11 90` (channel and angle), `all 90`, `run sit`, `servo 0 95`, `trim 0 2`, `limit 0 70 110`, `run walk`, `rn wb`, `rn tl`, `rn tr`, `face happy`.

## Servo mapping
Logical channels 0..11 map to physical PCA9685 outputs 0,1,2,4,5,6,8,9,10,12,14? **Correct mapping:** 0,1,2,4,5,6,8,9,10,12,13,14. For each leg: coxa, femur, tibia.

## Calibration and safety
- Defaults are 70..110 degrees, trim 0. These are initial software limits, not a guarantee of collision-free motion.
- Start with robot lifted, test one joint at a time, and check the linkage by hand with power disconnected. If a servo buzzes, strains, or a leg touches the frame, disconnect servo power immediately.
- Calibration trim and limits are saved in ESP32 Preferences flash. `trim <channel> <offset>` supports -25..25. `limit <channel> <min> <max>` stores safe limits.
- The movement patterns are basic demonstrations and have not been mechanically validated for your chassis. Do not expect stable walking without tuning the joint directions, mounting offsets, and gait timing.
- The sketch has not been compiled on your physical ESP32 hardware. Verify compile output and test with servos unloaded/lifted before use.
